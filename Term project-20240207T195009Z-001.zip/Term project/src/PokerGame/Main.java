package PokerGame;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Poker Game");
        frame.setLayout(null);
        Window win = new Window();
        frame.setContentPane(win);
        frame.setResizable(false);
        frame.setSize(1000, 1000);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }
}
